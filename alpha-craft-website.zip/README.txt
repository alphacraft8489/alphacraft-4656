# Alpha Craft Website

## Included
- `index.html` — website content
- `style.css` — responsive black/white luxury styling
- WhatsApp buttons connected to 8754939146
- Kovilpatti, Tamil Nadu contact details
- Services and gallery placeholders

## Add your real photos
Create a folder named `images` beside `index.html`, then put your photos there.
Replace a gallery placeholder in `index.html` with:
`<img src="images/your-photo.jpg" alt="Alpha Craft wedding invitation">`

## Free publishing
You can publish this site free using GitHub Pages, Netlify, or Cloudflare Pages.
